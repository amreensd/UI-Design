class switch2{
	void switchfr(String fruit) {
  var x = switch(fruit){
    	'Apple' || 'apple' => fruit,
	   
    	'Mango'|| 'mango'=> fruit,
	   

    	'Grapes' || 'grapes'=> fruit,
           	   
	'Watermelon' || 'watermelon ' =>fruit,

         		_ =>"Not Listed", 
	   };

	print(x);
        }

  }

